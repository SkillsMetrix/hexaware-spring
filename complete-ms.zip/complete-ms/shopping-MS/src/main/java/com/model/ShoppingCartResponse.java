package com.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data

@Builder
public class ShoppingCartResponse {
	private Long userId;
	private Long cartId;

	private Double totalCosts;

	private Integer totalItems;
	private List<Product>products;

}
