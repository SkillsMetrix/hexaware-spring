package com.example.shop_config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
