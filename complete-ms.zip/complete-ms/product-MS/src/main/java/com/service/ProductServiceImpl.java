package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.entity.Product;
import com.repo.ProductRepo;


@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepo repo;

	@Override
	public Product addProduct(Product product) {
		return repo.save(product);
	}

	@Override
	public List<Product> getProducts() {
		
		return (List<Product>)repo.findAll();
	}

	@Override
	public List<Product> getProductsByIds(List<Long> plist) {
		 
		return (List<Product>)repo.findAllById(plist);
	}

	
}
