package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;

@Service
public class UserServiceImpl implements UserService {

	static List<Users> userList = new ArrayList<Users>();

	static {
		userList.add(new Users("admin", "admin@mail.com", "pass123", "NY"));
		userList.add(new Users("manager", "manager@mail.com", "pass123", "MEL"));
	}

	@Override
	public void registerUser(Users users) {
		userList.add(users);
		System.out.println(userList);

	}

	@Override
	public boolean loginUser(Users users) {
		for (Users user : userList) {
			if (user.getUsername().equals(users.getUsername())) {
				return true;
			}

		}
		return false;

	}

	@Override
	public List<Users> loadUsers() {
		// TODO Auto-generated method stub
		return userList;
	}

	@Override
	public boolean findUser(String name) {

		for (Users user : userList) {
			if (user.getUsername().equals(name)) {
				return true;
			}

		}
		return false;
	}

	@Override
	public boolean deleteUser(String name) {
		for (Users user : userList) {

			boolean found = userList.removeIf(us -> user.getUsername().equals(name));
			if (found) {
				return true;
			}

		}

		return false;
	}

	@Override
	public void updateUser(String name,Users users) {
		
		System.out.println(users);
		System.out.println(name);
	}
}
