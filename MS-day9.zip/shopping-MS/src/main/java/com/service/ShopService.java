package com.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.entity.CartEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Product;
import com.model.ShoppingCartRequest;
import com.model.ShoppingCartResponse;
import com.repo.ShopRepo;



@Service
public class ShopService {
	@Autowired
	private ShopRepo repo;
	@Autowired
	private RestTemplate restTemplate;
	
	
	public ShoppingCartResponse processAndSend(Long UserId,List<ShoppingCartRequest> shoppingCartRequests) {
		
		ObjectMapper mapper= new ObjectMapper();
		String productServiceURL="http://product-ms/products/getproducts/" +
		shoppingCartRequests.stream()
		.map(e-> String.valueOf(e.getProductId()))
		.collect(Collectors.joining(","));
		Product[] productArray= restTemplate.getForObject(productServiceURL,Product[].class);
		List<Product> psl=Arrays.asList(productArray);
		
		double totalCosts=0.0;
		for(Product p:psl) {
			for(ShoppingCartRequest cr: shoppingCartRequests) {
				if(p.getProductId().equals(cr.getProductId())) {
					p.setQuantity(cr.getQuantity());
					totalCosts += p.getAmount()*cr.getQuantity();
					
				}
			}
		}
		CartEntity cartEntity=null;
		try {
			cartEntity=CartEntity.builder()
					.userId(UserId)
					.cartId((long)(Math.random()*Math.pow(10, 10)))
					.totalItems(psl.size())
					.totalCosts(totalCosts)
					.products(mapper.writeValueAsString(psl))
					.build();
			cartEntity=repo.save(cartEntity);
			}catch (Exception e) {}
		return ShoppingCartResponse.builder()
				.cartId(cartEntity.getCartId())
				.userId(cartEntity.getUserId())
				.totalItems(cartEntity.getTotalItems())
				.totalCosts(cartEntity.getTotalCosts())
				.products(psl)
				.build();
		
	}
	public List<ShoppingCartResponse> getShoppingCart(Long userid){
		ObjectMapper mapper= new ObjectMapper();
		List<CartEntity> cartEntities= repo.findByUserId(userid);
		List<ShoppingCartResponse> cartResponse= cartEntities.stream()
				.map(ce -> {
					try {
						return ShoppingCartResponse.builder()
								.cartId(ce.getCartId())
								.userId(ce.getUserId())
								.totalItems(ce.getTotalItems())
								.totalCosts(ce.getTotalCosts())
								.products(mapper.readValue(ce.getProducts(),List.class))
								.build();
					}catch (Exception e) {
						throw new RuntimeException();
					}
					
				}).collect(Collectors.toList());
		return cartResponse;
	}
	
}
