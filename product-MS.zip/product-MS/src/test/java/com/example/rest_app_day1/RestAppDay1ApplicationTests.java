package com.example.rest_app_day1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestAppDay1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
