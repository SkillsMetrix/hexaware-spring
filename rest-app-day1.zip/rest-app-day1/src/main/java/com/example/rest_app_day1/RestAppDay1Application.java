package com.example.rest_app_day1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestAppDay1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestAppDay1Application.class, args);
	}

}
