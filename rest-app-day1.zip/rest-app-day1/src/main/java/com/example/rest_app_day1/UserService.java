package com.example.rest_app_day1;

public interface UserService {
	
	public void registerUser(Users users);
	

}
