package com.example.rest_app_day1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/mainapp")
public class RestApp {
	
  List<Users> userList= new ArrayList<Users>();
  
  @Autowired
  private UserService service;

	@RequestMapping(method = RequestMethod.GET,path = "/welcome")
	@ResponseBody
	public String sayWelcome() {
		return "Welcome to SpringBoot";
	}
	@RequestMapping(method = RequestMethod.POST,path = "/login")
	@ResponseBody
	public String login(@RequestBody Users users) {
		for( Users user: userList) {
			if(user.getUsername().equals(users.getUsername())) {
				return "login Success";
			}
		}
		return "login failed";
	}
	@RequestMapping(method = RequestMethod.POST,path = "/register")
	@ResponseBody
	public String register(@RequestBody Users users) {
		 service.registerUser(users);
		
		
		return "Welcome to register";
	}
}
