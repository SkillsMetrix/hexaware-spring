package com.example.rest_app_day1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{
	
	 List<Users> userList= new ArrayList<Users>();

	@Override
	public void registerUser(Users users) {
		userList.add(users);
		System.out.println(userList);
		 
		
	}

}
