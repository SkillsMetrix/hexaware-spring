package com.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Users;

@Repository
public interface AppRepo extends JpaRepository<Users, String> {
	
	@Modifying
	@Transactional
	@Query("UPDATE Users u SET u.username=:username,u.password=:password,u.city=:city WHERE u.email=:email" )
	int updateUserById(@Param("email") String email,@Param("username") String username,
			@Param("password") String password, @Param("city") String city

	);
	@Modifying
	@Transactional
	@Query("DELETE FROM Users u WHERE u.email =:email")
	int deleteUserById(@Param("email")String email);

}
