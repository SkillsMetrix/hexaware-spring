package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SecurityController {
	
	@GetMapping("/admin")
	public String admin() {
		return "admin";
	}
	@GetMapping("/welcome")
	public String welcome() {
		return "welcome";
	}

	@GetMapping("/manager")
	public String manager() {
		return "manager";
	}
	@GetMapping("/common")
	public String common() {
		return "common";
	}
}
